//
//  BinaryPod.h
//  BinaryPod
//
//  Created by Grimm, Stephan on 01.10.21.
//

#import <Foundation/Foundation.h>

//! Project version number for BinaryPod.
FOUNDATION_EXPORT double BinaryPodVersionNumber;

//! Project version string for BinaryPod.
FOUNDATION_EXPORT const unsigned char BinaryPodVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BinaryPod/PublicHeader.h>


